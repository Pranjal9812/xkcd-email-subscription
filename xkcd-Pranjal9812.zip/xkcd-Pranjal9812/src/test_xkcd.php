<?php
include 'functions.php';
echo fetchAndFormatXKCDData();


